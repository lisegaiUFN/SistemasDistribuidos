package exemplo2;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

public class ServidorTCPBasico {

    public static void main(String[] args) {
        try {
            int portaServidor = 3333;
            ServerSocket servidor = new ServerSocket(portaServidor);
            System.out.println("Servidor ouvindo a porta: " + portaServidor);
            Socket cliente; //procurador do cliente no lado do servidor
            ArrayList<Pessoa> lista = new ArrayList<>();
            Boolean encontrado;
            
            while (true) {
                

                // o método accept() bloqueia a execução até que
                // o servidor receba um pedido de conexão
                cliente = servidor.accept();
                //Receber o nome completo do lado do cliente
                
                //Gerar email a partir do nome completo: primeiro.sobrenome@ufn.edu.br
                
                //Criar um objeto Pessoa que vai ter um nome enviado e o objeto criado Pessoa(nome,email)
                
                //Adicionar na lista de controle de emails (verificando duplicidade) e devolvendo o email gerado 
                
                //Devolver objeto criado
                System.out.println("Cliente conectado: " + cliente.getInetAddress().getHostAddress());
                ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());
                try{
                    String nomePessoa = (String)entrada.readObject();
                    String email = vetornome[0] + "."+vetorNome[vetorNome.lenght-1]+"@ufn.edu.br";
                    nomePessoa = nomePessoa.toUpperCase();
                    email=email.toUpperCase();
                    
                    if(lista.contains(p)){
                        encontrado=true;
                        System.gc(); //Limpa gc = garbage colector
                    } else {
                        lista.add(p);
                    }
                }
                saida.flush();
                saida.writeObject(new Date());
                saida.close();
                cliente.close();
            }
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        } 
    }
}
