package exemplo1;

import java.net.*; //Profissionalmente, o * é proibido. Se deve colocar biblioteca 1 por 1
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class MiniChatServer {

    static BufferedReader tecladoTerminal = new BufferedReader(new InputStreamReader(System.in));
    static ServerSocket socketServidor;
    static Socket socketCliente;
    static ObjectOutputStream saida;
    static ObjectInputStream entrada;

    public static void main(String[] args) throws IOException {
        String apelido = "A1";
        int portaNumero = 50000; //Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a porta logica liberada"));
        long tempoInicio;
        try {
            //Até linha 30 poderia ser circundado em uma thread e serve para colocar no ar o servidor e ele ficar aguardando um cliente
            socketServidor = new ServerSocket(portaNumero);
            System.out.println("Servidor em funcionamento");
            //Temporizador: 
            tempoInicio = System.nanoTime();
            socketCliente = socketServidor.accept();
            System.out.println("Tempo de conexão do primeiro cliente ao servidor: " + (System.nanoTime() - tempoInicio) / 1000000);
            saida = new ObjectOutputStream(socketCliente.getOutputStream());

            entrada = new ObjectInputStream(socketCliente.getInputStream()); //SocketCliente é um representante do cliente no lado do servidor

            new Thread() {
                @Override
                public void run() {
                    String fraseDoCliente;
                    try {
                        while ((fraseDoCliente = (String) entrada.readObject()) != null) {
                            System.out.println("Msg do cliente: " + fraseDoCliente);
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(MiniChatServer.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }.start();

            String fraseDoServidor;
            do {
                fraseDoServidor = tecladoTerminal.readLine();
                saida.flush();
                saida.writeObject((apelido + ": " + fraseDoServidor));
            } while (fraseDoServidor != null);
        } catch (IOException e) {
            System.out.println("Exceção capturada ao ouvir/ler a porta "
                    + portaNumero + " ou ao tentar conectar");
            System.out.println(e.getMessage());
        }
        saida.close();
        entrada.close();
        socketCliente.close();
        socketServidor.close();
        System.exit(0);
    }
}
